<?php
namespace Admin\Controller;
use Admin\Common\Controller\CommonController;
class IndexController extends CommonController {
    public function index(){
        $this->display();
    }
}