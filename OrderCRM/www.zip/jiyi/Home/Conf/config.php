<?php
return array(
	//'配置项'=>'配置值'
    //开启路由模式
    'URL_ROUTER_ON'   => true,
    'URL_ROUTE_RULES' => array( //定义路由规则
        'login.html'       => array('Login/index'),
    ),




);